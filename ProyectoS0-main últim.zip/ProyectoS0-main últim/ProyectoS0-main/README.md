# ProyectoS0
versión 5 (actually 4): submitted by Manel, developed by Hugo,Manel, Laura and Esther, revised by the four members of the group and explained in the videos by Manel
https://youtu.be/_zU3Fcti1Iw?si=OYR9fTg9d6K--Jnw




