﻿namespace Battleship
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.form2_shoot_button = new System.Windows.Forms.Button();
            this.form2_send_fleet_position_button = new System.Windows.Forms.Button();
            this.OPONENTS__lbl = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.user_dataGridView = new System.Windows.Forms.DataGridView();
            this.opponent_dataGridView = new System.Windows.Forms.DataGridView();
            this.user_game_form_label = new System.Windows.Forms.Label();
            this.opponent_game_form_label = new System.Windows.Forms.Label();
            this.send_message = new System.Windows.Forms.Button();
            this.input = new System.Windows.Forms.RichTextBox();
            this.output = new System.Windows.Forms.RichTextBox();
            ((System.ComponentModel.ISupportInitialize)(this.user_dataGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.opponent_dataGridView)).BeginInit();
            this.SuspendLayout();
            // 
            // form2_shoot_button
            // 
            this.form2_shoot_button.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.form2_shoot_button.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.form2_shoot_button.Location = new System.Drawing.Point(873, 689);
            this.form2_shoot_button.Name = "form2_shoot_button";
            this.form2_shoot_button.Size = new System.Drawing.Size(215, 77);
            this.form2_shoot_button.TabIndex = 2;
            this.form2_shoot_button.Text = "Shoot";
            this.form2_shoot_button.UseVisualStyleBackColor = false;
            this.form2_shoot_button.Click += new System.EventHandler(this.button1_Click);
            // 
            // form2_send_fleet_position_button
            // 
            this.form2_send_fleet_position_button.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.form2_send_fleet_position_button.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.form2_send_fleet_position_button.Location = new System.Drawing.Point(591, 689);
            this.form2_send_fleet_position_button.Name = "form2_send_fleet_position_button";
            this.form2_send_fleet_position_button.Size = new System.Drawing.Size(199, 77);
            this.form2_send_fleet_position_button.TabIndex = 3;
            this.form2_send_fleet_position_button.Text = "Send Fleet Position";
            this.form2_send_fleet_position_button.UseVisualStyleBackColor = false;
            this.form2_send_fleet_position_button.Click += new System.EventHandler(this.form2_send_fleet_position_button_Click);
            // 
            // OPONENTS__lbl
            // 
            this.OPONENTS__lbl.AutoSize = true;
            this.OPONENTS__lbl.BackColor = System.Drawing.Color.Transparent;
            this.OPONENTS__lbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.OPONENTS__lbl.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.OPONENTS__lbl.Location = new System.Drawing.Point(1022, 157);
            this.OPONENTS__lbl.Name = "OPONENTS__lbl";
            this.OPONENTS__lbl.Size = new System.Drawing.Size(178, 20);
            this.OPONENTS__lbl.TabIndex = 15;
            this.OPONENTS__lbl.Text = "OPPONENT\'S SHIPS";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label2.Location = new System.Drawing.Point(490, 157);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(94, 20);
            this.label2.TabIndex = 14;
            this.label2.Text = "MY SHIPS";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 6F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(1439, 252);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(119, 210);
            this.label4.TabIndex = 13;
            this.label4.Text = "Aircraft Carrier x1\r\nAAAAA\r\n\r\nBattleship x2\r\nBBBB\r\n\r\nCruiser x3\r\nCCC\r\n\r\nSubmarine" +
    " x4\r\nSS\r\n\r\nDestroyer x5\r\nD";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 6F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(93, 252);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(119, 210);
            this.label3.TabIndex = 12;
            this.label3.Text = "Aircraft Carrier x1\r\nAAAAA\r\n\r\nBattleship x2\r\nBBBB\r\n\r\nCruiser x3\r\nCCC\r\n\r\nSubmarine" +
    " x4\r\nSS\r\n\r\nDestroyer x5\r\nD";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // user_dataGridView
            // 
            this.user_dataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.user_dataGridView.Location = new System.Drawing.Point(273, 211);
            this.user_dataGridView.Name = "user_dataGridView";
            this.user_dataGridView.RowHeadersWidth = 51;
            this.user_dataGridView.RowTemplate.Height = 24;
            this.user_dataGridView.Size = new System.Drawing.Size(496, 428);
            this.user_dataGridView.TabIndex = 16;
            this.user_dataGridView.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.user_dataGridView_CellClick);
            // 
            // opponent_dataGridView
            // 
            this.opponent_dataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.opponent_dataGridView.Location = new System.Drawing.Point(905, 229);
            this.opponent_dataGridView.Name = "opponent_dataGridView";
            this.opponent_dataGridView.RowHeadersWidth = 51;
            this.opponent_dataGridView.RowTemplate.Height = 24;
            this.opponent_dataGridView.Size = new System.Drawing.Size(496, 428);
            this.opponent_dataGridView.TabIndex = 17;
            this.opponent_dataGridView.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.opponent_dataGridView_CellClick);
            // 
            // user_game_form_label
            // 
            this.user_game_form_label.AutoSize = true;
            this.user_game_form_label.Location = new System.Drawing.Point(633, 157);
            this.user_game_form_label.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.user_game_form_label.Name = "user_game_form_label";
            this.user_game_form_label.Size = new System.Drawing.Size(0, 20);
            this.user_game_form_label.TabIndex = 18;
            // 
            // opponent_game_form_label
            // 
            this.opponent_game_form_label.AutoSize = true;
            this.opponent_game_form_label.BackColor = System.Drawing.SystemColors.Window;
            this.opponent_game_form_label.Location = new System.Drawing.Point(1222, 165);
            this.opponent_game_form_label.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.opponent_game_form_label.Name = "opponent_game_form_label";
            this.opponent_game_form_label.Size = new System.Drawing.Size(0, 20);
            this.opponent_game_form_label.TabIndex = 19;
            // 
            // send_message
            // 
            this.send_message.Location = new System.Drawing.Point(273, 689);
            this.send_message.Name = "send_message";
            this.send_message.Size = new System.Drawing.Size(140, 41);
            this.send_message.TabIndex = 21;
            this.send_message.Text = "Send message";
            this.send_message.UseVisualStyleBackColor = true;
            this.send_message.Click += new System.EventHandler(this.button2_Click);
            // 
            // input
            // 
            this.input.Location = new System.Drawing.Point(49, 638);
            this.input.Name = "input";
            this.input.Size = new System.Drawing.Size(163, 53);
            this.input.TabIndex = 23;
            this.input.Text = "";
            this.input.TextChanged += new System.EventHandler(this.input_TextChanged);
            // 
            // output
            // 
            this.output.Location = new System.Drawing.Point(49, 716);
            this.output.Name = "output";
            this.output.Size = new System.Drawing.Size(163, 50);
            this.output.TabIndex = 24;
            this.output.Text = "";
            this.output.TextChanged += new System.EventHandler(this.output_TextChanged);
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::Battleship.Properties.Resources.sea_wallpaper;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1237, 866);
            this.Controls.Add(this.output);
            this.Controls.Add(this.input);
            this.Controls.Add(this.send_message);
            this.Controls.Add(this.opponent_game_form_label);
            this.Controls.Add(this.user_game_form_label);
            this.Controls.Add(this.opponent_dataGridView);
            this.Controls.Add(this.user_dataGridView);
            this.Controls.Add(this.OPONENTS__lbl);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.form2_send_fleet_position_button);
            this.Controls.Add(this.form2_shoot_button);
            this.Name = "Form2";
            this.Text = "Form2";
            this.Load += new System.EventHandler(this.Form2_Load);
            ((System.ComponentModel.ISupportInitialize)(this.user_dataGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.opponent_dataGridView)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button form2_shoot_button;
        private System.Windows.Forms.Button form2_send_fleet_position_button;
        private System.Windows.Forms.Label OPONENTS__lbl;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.DataGridView user_dataGridView;
        private System.Windows.Forms.DataGridView opponent_dataGridView;
        private System.Windows.Forms.Label user_game_form_label;
        private System.Windows.Forms.Label opponent_game_form_label;
        private System.Windows.Forms.Button send_message;
        private System.Windows.Forms.RichTextBox input;
        private System.Windows.Forms.RichTextBox output;
    }
}